package operaciones.practica1;

public class Operaciones {
    public static int suma(String a, String b){
        int s;
        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);
        s= num1+num2;
        return s;
    }
     public static int resta(String a, String b){
        int r;
        int num1= Integer.parseInt(a);
        int num2 = Integer.parseInt(b);
        r= num1-num2;
        return r;
    }
      public static int multiplicacion(String a, String b){
        int m;
        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);
        m= num1*num2;
        return m;
    }
      public static int division(String a, String b){
        int d;
        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);
        d= num1/num2;
        return d;
    }
      public static int op(String a, String b){
        int p;
        int num1 = Integer.parseInt(a);
        int num2 = Integer.parseInt(b);
        p= num1%num2;
        return p;
    }
    
}
