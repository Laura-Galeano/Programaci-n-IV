/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package img;

import java.awt.*;
/**
 *
 * @author Administrador
 */
public class Imagenes {
    public Image cargar(String Ruta){
        return Toolkit.getDefaultToolkit().createImage((getClass().getResource(Ruta)));
    }
}
