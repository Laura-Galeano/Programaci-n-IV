/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package batallan;


public class BatallaN {
    
    public BatallaN(){
        Menu begin= new Menu();
        begin.setVisible(true);
        begin.setLocationRelativeTo(null);
    }
   
    public static void main(String[] args) {
        BatallaN Game= new BatallaN();
    }
    
}
